import WorkforcePulse2025 from "@/features/dashboard/WorkforcePulse2025";
export default function Home() { return <WorkforcePulse2025 />; }
